<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

// Simulate admin login for testing
$_SESSION['role'] = 'admin';
$_SESSION['username'] = 'admin';

echo "<h1>Comprehensive Tutor Assignment Test</h1>";

// Test 1: Check getTutors function output
echo "<h2>1. getTutors() Function Output</h2>";
$tutors = getTutors();
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>ID</th><th>Name</th><th>Username</th><th>Specialization</th><th>Legacy User ID</th></tr>";
foreach ($tutors as $tutor) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($tutor['id']) . "</td>";
    echo "<td>" . htmlspecialchars($tutor['name']) . "</td>";
    echo "<td>" . htmlspecialchars($tutor['username']) . "</td>";
    echo "<td>" . htmlspecialchars($tutor['specialization'] ?? 'General') . "</td>";
    echo "<td>" . htmlspecialchars($tutor['legacy_user_id']) . "</td>";
    echo "</tr>";
}
echo "</table>";

// Test 2: Verify dropdown options match what admin sees
echo "<h2>2. Admin Dropdown Options (what should appear in form)</h2>";
echo "<select style='width: 100%; padding: 8px; font-size: 14px;'>";
echo "<option value=''>Select Tutor</option>";
foreach ($tutors as $tutor) {
    $specialization = (!empty($tutor['specialization']) && $tutor['specialization'] !== 'General') 
        ? ' - ' . $tutor['specialization'] 
        : '';
    echo "<option value='" . htmlspecialchars($tutor['id']) . "'>" . 
         htmlspecialchars($tutor['name']) . $specialization . "</option>";
}
echo "</select>";

// Test 3: Check current program assignments
echo "<h2>3. Current Program Assignments</h2>";
$sql = "SELECT p.id, p.name, p.tutor_id, u.username, u.role, 
               CONCAT(tp.first_name, ' ', tp.last_name) as tutor_name
        FROM programs p 
        LEFT JOIN users u ON p.tutor_id = u.id
        LEFT JOIN tutor_profiles tp ON u.id = tp.user_id
        ORDER BY p.id DESC LIMIT 10";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Program ID</th><th>Program Name</th><th>Tutor ID</th><th>Username</th><th>Role</th><th>Tutor Name</th><th>Status</th></tr>";
    while ($row = $result->fetch_assoc()) {
        $status = 'OK';
        $style = '';
        if ($row['tutor_id'] && $row['role'] !== 'tutor') {
            $status = 'ERROR: Assigned to non-tutor!';
            $style = 'background-color: #fee; color: #c00;';
        } elseif (!$row['tutor_id']) {
            $status = 'No tutor assigned';
            $style = 'background-color: #ffa; color: #660;';
        }
        
        echo "<tr style='$style'>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tutor_id'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($row['username'] ?? 'N/A') . "</td>";
        echo "<td>" . htmlspecialchars($row['role'] ?? 'N/A') . "</td>";
        echo "<td>" . htmlspecialchars($row['tutor_name'] ?? 'N/A') . "</td>";
        echo "<td><strong>" . $status . "</strong></td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Test 4: Validate ID mappings
echo "<h2>4. ID Mapping Validation</h2>";
echo "<p><strong>Valid Tutor IDs for Assignment:</strong> ";
foreach ($tutors as $tutor) {
    echo $tutor['id'] . " (" . $tutor['name'] . "), ";
}
echo "</p>";

echo "<p><strong>Important Notes:</strong></p>";
echo "<ul>";
echo "<li>Tutor dropdown should show IDs: " . implode(', ', array_column($tutors, 'id')) . "</li>";
echo "<li>Sarah Geronimo should have ID: 13</li>";
echo "<li>Jane Tutor should have ID: 4</li>";
echo "<li>Any program assigned to ID 2 is WRONG (that's a student)</li>";
echo "</ul>";

echo "<h2>5. Test API Call Simulation</h2>";
echo "<p>If admin selects 'Sarah Pamintuan Geronimo' from dropdown, the form should send: tutor_id = 13</p>";
echo "<p>If admin selects 'Jane Tutor' from dropdown, the form should send: tutor_id = 4</p>";
echo "<p style='color: green;'><strong>✅ System Status: " . (count($tutors) > 0 ? "Ready for testing" : "ERROR: No tutors found") . "</strong></p>";
?>