<?php
include 'includes/db.php';

// First get the numeric ID for user TPS2025-001
$result = mysqli_query($conn, "SELECT id FROM users WHERE user_id = 'TPS2025-001'");
if ($result && mysqli_num_rows($result) > 0) {
    $user = mysqli_fetch_assoc($result);
    $numeric_user_id = $user['id'];
    echo "Found user TPS2025-001 with numeric ID: $numeric_user_id\n";
    
    // Create enrollment using numeric ID
    $sql = "INSERT INTO enrollments (student_user_id, program_id, enrollment_date, status) VALUES ($numeric_user_id, 32, NOW(), 'active') ON DUPLICATE KEY UPDATE status = 'active'";
    
    if (mysqli_query($conn, $sql)) {
        echo "Enrollment created/updated successfully\n";
    } else {
        echo "Error: " . mysqli_error($conn) . "\n";
    }
    
    // Verify enrollment
    $result = mysqli_query($conn, "SELECT * FROM enrollments WHERE student_user_id = $numeric_user_id AND program_id = 32");
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo "Verification: Student $numeric_user_id is enrolled in program 32 with status: {$row['status']}\n";
    } else {
        echo "Verification failed: Student not found in enrollments\n";
    }
} else {
    echo "User TPS2025-001 not found\n";
}
?>