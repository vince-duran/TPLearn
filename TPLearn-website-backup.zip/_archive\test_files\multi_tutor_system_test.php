<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

echo "<h1>🧪 Multi-Tutor System Verification</h1>";

// Test data: All tutors in the system
$tutors_test_data = [
    [
        'id' => 4,
        'user_id' => 'TPT2025-001',
        'username' => 'testtutor',
        'name' => 'Jane Tutor',
        'expected_programs' => 2
    ],
    [
        'id' => 13,
        'user_id' => 'TPT2025-577', 
        'username' => 'TUT2025-745',
        'name' => 'Sarah Geronimo',
        'expected_programs' => 5
    ]
];

echo "<h2>1. Database Consistency Check</h2>";

// Check if all tutors have proper profiles
$sql = "SELECT u.id, u.user_id, u.username, u.role, 
               tp.first_name, tp.last_name,
               COUNT(p.id) as assigned_programs
        FROM users u 
        LEFT JOIN tutor_profiles tp ON u.id = tp.user_id 
        LEFT JOIN programs p ON u.id = p.tutor_id
        WHERE u.role = 'tutor' 
        GROUP BY u.id, u.user_id, u.username, u.role, tp.first_name, tp.last_name
        ORDER BY u.id";

$result = $conn->query($sql);

echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>User ID</th><th>String ID</th><th>Username</th><th>Full Name</th><th>Has Profile</th><th>Assigned Programs</th><th>Status</th></tr>";

$tutor_data = [];
while ($row = $result->fetch_assoc()) {
    $has_profile = !empty($row['first_name']) && !empty($row['last_name']);
    $full_name = $has_profile ? trim($row['first_name'] . ' ' . $row['last_name']) : 'No Profile';
    $status = $has_profile ? '✅ OK' : '❌ Missing Profile';
    
    echo "<tr>";
    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['user_id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['username']) . "</td>";
    echo "<td>" . htmlspecialchars($full_name) . "</td>";
    echo "<td>" . ($has_profile ? 'Yes' : 'No') . "</td>";
    echo "<td>" . htmlspecialchars($row['assigned_programs']) . "</td>";
    echo "<td><strong>$status</strong></td>";
    echo "</tr>";
    
    $tutor_data[] = $row;
}
echo "</table>";

echo "<h2>2. Function Testing for Each Tutor</h2>";

foreach ($tutors_test_data as $tutor) {
    echo "<div style='border: 2px solid #e5e7eb; border-radius: 8px; padding: 20px; margin: 20px 0;'>";
    echo "<h3>🧑‍🏫 Testing: {$tutor['name']} (ID: {$tutor['id']})</h3>";
    
    // Test with integer ID (session scenario)
    echo "<h4>A. Session Simulation (Integer ID: {$tutor['id']})</h4>";
    
    $full_name = getTutorFullName($tutor['id']);
    echo "<p><strong>getTutorFullName({$tutor['id']}):</strong> " . htmlspecialchars($full_name) . "</p>";
    
    $programs = getTutorAssignedPrograms($tutor['id']);
    $program_count = count($programs);
    echo "<p><strong>getTutorAssignedPrograms({$tutor['id']}):</strong> $program_count programs found</p>";
    
    // Test with string ID (alternative scenario)
    echo "<h4>B. String ID Test ('{$tutor['user_id']}')</h4>";
    
    $full_name_string = getTutorFullName($tutor['user_id']);
    echo "<p><strong>getTutorFullName('{$tutor['user_id']}'):</strong> " . htmlspecialchars($full_name_string) . "</p>";
    
    $programs_string = getTutorAssignedPrograms($tutor['user_id']);
    $program_count_string = count($programs_string);
    echo "<p><strong>getTutorAssignedPrograms('{$tutor['user_id']}'):</strong> $program_count_string programs found</p>";
    
    // Validation
    $integer_test_pass = ($program_count == $tutor['expected_programs']);
    $string_test_pass = ($program_count_string == $tutor['expected_programs']);
    $consistent = ($program_count == $program_count_string);
    
    echo "<h4>C. Validation Results</h4>";
    echo "<ul>";
    echo "<li><strong>Integer ID Test:</strong> " . ($integer_test_pass ? "✅ PASS" : "❌ FAIL") . " (Expected: {$tutor['expected_programs']}, Got: $program_count)</li>";
    echo "<li><strong>String ID Test:</strong> " . ($string_test_pass ? "✅ PASS" : "❌ FAIL") . " (Expected: {$tutor['expected_programs']}, Got: $program_count_string)</li>";
    echo "<li><strong>Consistency:</strong> " . ($consistent ? "✅ PASS" : "❌ FAIL") . " (Both methods return same result)</li>";
    echo "</ul>";
    
    // Show program details if any found
    if (!empty($programs)) {
        echo "<h4>D. Assigned Programs</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Name</th><th>Status</th><th>Students</th><th>Progress</th></tr>";
        foreach ($programs as $program) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($program['id']) . "</td>";
            echo "<td>" . htmlspecialchars($program['name']) . "</td>";
            echo "<td>" . htmlspecialchars($program['program_status']) . "</td>";
            echo "<td>" . htmlspecialchars($program['enrolled_students']) . "</td>";
            echo "<td>" . htmlspecialchars($program['progress_percentage']) . "%</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    $overall_status = ($integer_test_pass && $string_test_pass && $consistent) ? "✅ ALL TESTS PASSED" : "❌ SOME TESTS FAILED";
    echo "<div style='background: " . ($overall_status[0] === '✅' ? '#d1fae5' : '#fee2e2') . "; padding: 10px; border-radius: 6px; margin: 10px 0;'>";
    echo "<strong>$overall_status</strong>";
    echo "</div>";
    
    echo "</div>";
}

echo "<h2>3. Admin Assignment System Test</h2>";

$tutors = getTutors();
echo "<p><strong>Available tutors for admin assignment:</strong></p>";
echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr><th>Dropdown Value (ID)</th><th>Display Name</th><th>Specialization</th><th>Assigned Programs</th></tr>";

foreach ($tutors as $tutor) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($tutor['id']) . "</td>";
    echo "<td>" . htmlspecialchars($tutor['name']) . "</td>";
    echo "<td>" . htmlspecialchars($tutor['specialization'] ?? 'General') . "</td>";
    echo "<td>" . htmlspecialchars($tutor['program_count'] ?? 0) . "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<h2>4. System Health Summary</h2>";

// Count successful tests
$total_tutors = count($tutors_test_data);
$successful_tests = 0;

foreach ($tutors_test_data as $tutor) {
    $programs_int = getTutorAssignedPrograms($tutor['id']);
    $programs_str = getTutorAssignedPrograms($tutor['user_id']);
    
    if (count($programs_int) == $tutor['expected_programs'] && 
        count($programs_str) == $tutor['expected_programs'] &&
        count($programs_int) == count($programs_str)) {
        $successful_tests++;
    }
}

$health_percentage = ($successful_tests / $total_tutors) * 100;
$health_status = ($health_percentage == 100) ? 'EXCELLENT' : (($health_percentage >= 80) ? 'GOOD' : 'NEEDS ATTENTION');
$health_color = ($health_percentage == 100) ? '#10b981' : (($health_percentage >= 80) ? '#f59e0b' : '#ef4444');

echo "<div style='background: white; border: 3px solid $health_color; border-radius: 12px; padding: 25px; text-align: center;'>";
echo "<h3 style='color: $health_color; margin: 0 0 15px 0;'>System Health: $health_status</h3>";
echo "<p style='font-size: 18px; margin: 0;'><strong>$successful_tests/$total_tutors tutors</strong> passing all tests (<strong>$health_percentage%</strong>)</p>";

if ($health_percentage == 100) {
    echo "<p style='color: #065f46; margin: 10px 0 0 0;'>✅ All tutors can successfully view their assigned programs!</p>";
    echo "<p style='color: #065f46; margin: 5px 0 0 0;'>✅ Admin assignment system working correctly for all tutors!</p>";
    echo "<p style='color: #065f46; margin: 5px 0 0 0;'>✅ Both integer and string ID methods working consistently!</p>";
} else {
    echo "<p style='color: #991b1b; margin: 10px 0 0 0;'>❌ Some tutors are experiencing issues - check individual test results above</p>";
}

echo "</div>";

echo "<h2>5. Quick Integration Test</h2>";
echo "<div style='background: #f0f9ff; padding: 15px; border-radius: 8px; border-left: 4px solid #0284c7;'>";
echo "<h4 style='color: #0284c7; margin: 0 0 10px 0;'>End-to-End Workflow:</h4>";
echo "<ol style='color: #0284c7; margin: 0;'>";
echo "<li><strong>Admin creates program</strong> → Selects any tutor from dropdown</li>";
echo "<li><strong>System stores assignment</strong> → programs.tutor_id = selected tutor's users.id</li>";
echo "<li><strong>Tutor logs in</strong> → Session stores their users.id</li>";
echo "<li><strong>Tutor views dashboard</strong> → Functions handle both ID types seamlessly</li>";
echo "<li><strong>Programs display correctly</strong> → All tutors see their assigned programs</li>";
echo "</ol>";
echo "</div>";

?>

<script>
// Add some visual polish
document.addEventListener('DOMContentLoaded', function() {
    // Highlight successful tests
    const successElements = document.querySelectorAll('li:contains("✅ PASS")');
    
    // Add smooth scroll for long page
    const style = document.createElement('style');
    style.textContent = `
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
        table { margin: 10px 0; }
        th { background-color: #f3f4f6; }
        td, th { padding: 8px 12px; }
        h1, h2, h3 { color: #111827; }
        h4 { color: #374151; }
    `;
    document.head.appendChild(style);
});
</script>