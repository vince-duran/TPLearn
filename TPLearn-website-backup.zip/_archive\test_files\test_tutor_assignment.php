<?php
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

echo "<h2>Testing Tutor Assignment System</h2>";

// Test 1: Check Sarah's assigned programs
echo "<h3>Test 1: Sarah's Assigned Programs</h3>";
$sarah_user_id = 'TPT2025-577'; // String user_id
$programs = getTutorAssignedPrograms($sarah_user_id);

echo "<p>Sarah's user_id: " . htmlspecialchars($sarah_user_id) . "</p>";
echo "<p>Number of assigned programs: " . count($programs) . "</p>";

if (!empty($programs)) {
    echo "<ul>";
    foreach ($programs as $program) {
        echo "<li>" . htmlspecialchars($program['name']) . " (ID: " . $program['id'] . ")</li>";
    }
    echo "</ul>";
} else {
    echo "<p>No programs found for Sarah.</p>";
}

// Test 2: Check tutor full name
echo "<h3>Test 2: Sarah's Full Name</h3>";
$full_name = getTutorFullName($sarah_user_id);
echo "<p>Full name: " . htmlspecialchars($full_name) . "</p>";

// Test 3: Show all tutors available for assignment
echo "<h3>Test 3: Available Tutors for Admin Assignment</h3>";
$tutors = getTutors();
echo "<p>Number of tutors: " . count($tutors) . "</p>";

if (!empty($tutors)) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID (for assignment)</th><th>Name</th><th>Username</th><th>String User ID</th></tr>";
    foreach ($tutors as $tutor) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($tutor['user_id']) . "</td>"; // This is the ID used for assignment
        echo "<td>" . htmlspecialchars($tutor['name']) . "</td>";
        echo "<td>" . htmlspecialchars($tutor['username']) . "</td>";
        echo "<td>" . htmlspecialchars($tutor['legacy_user_id']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}

// Test 4: Check current programs assignments
echo "<h3>Test 4: Current Program Assignments</h3>";
$sql = "SELECT p.id, p.name, p.tutor_id, u.user_id as tutor_string_id, tp.first_name, tp.last_name 
        FROM programs p 
        LEFT JOIN tutor_profiles tp ON p.tutor_id = tp.user_id 
        LEFT JOIN users u ON tp.user_id = u.id
        ORDER BY p.id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Program ID</th><th>Program Name</th><th>Tutor ID (stored)</th><th>Tutor String ID</th><th>Tutor Name</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tutor_id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tutor_string_id'] ?? 'N/A') . "</td>";
        echo "<td>" . htmlspecialchars(trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')) ?: 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No programs found.</p>";
}
?>