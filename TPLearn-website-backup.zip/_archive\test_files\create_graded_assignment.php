<?php
include 'includes/db.php';

// Get the numeric user ID for TPS2025-001
$result = $conn->query("SELECT id FROM users WHERE user_id = 'TPS2025-001'");
if ($result && $row = $result->fetch_assoc()) {
    $numeric_student_id = $row['id'];
    echo "Found student with numeric ID: $numeric_student_id\n";
} else {
    echo "Student TPS2025-001 not found\n";
    exit();
}

$assignment_id = 6; // Using assignment "koiojik"

echo "Creating graded assignment submission for testing...\n";

// First, create a submission
$stmt = $conn->prepare("
    INSERT INTO assignment_submissions 
    (assignment_id, student_id, submission_text, submitted_at, is_late, grade, feedback, status, graded_by, graded_at) 
    VALUES (?, ?, 'Sample submission text for testing', NOW() - INTERVAL 2 DAY, 0, 85.00, 'Great work! You demonstrated a solid understanding of the concepts. Consider expanding on the implementation details in future assignments.', 'graded', 2, NOW() - INTERVAL 1 DAY)
    ON DUPLICATE KEY UPDATE 
    grade = 85.00, 
    feedback = 'Great work! You demonstrated a solid understanding of the concepts. Consider expanding on the implementation details in future assignments.', 
    status = 'graded', 
    graded_by = 2, 
    graded_at = NOW() - INTERVAL 1 DAY
");

$stmt->bind_param('ii', $assignment_id, $numeric_student_id);

if ($stmt->execute()) {
    echo "Graded submission created successfully!\n";
    
    // Verify the creation
    $result = $conn->query("
        SELECT asub.*, pm.title, u.username as grader_name
        FROM assignment_submissions asub 
        JOIN program_materials pm ON asub.assignment_id = pm.id
        LEFT JOIN users u ON asub.graded_by = u.id
        WHERE asub.assignment_id = $assignment_id AND asub.student_id = $numeric_student_id
    ");
    
    if ($row = $result->fetch_assoc()) {
        echo "\nSubmission Details:\n";
        echo "- Assignment: {$row['title']}\n";
        echo "- Grade: {$row['grade']}/100\n";
        echo "- Feedback: {$row['feedback']}\n";
        echo "- Status: {$row['status']}\n";
        echo "- Graded by: {$row['grader_name']}\n";
        echo "- Graded at: {$row['graded_at']}\n";
    }
} else {
    echo "Error creating submission: " . $conn->error . "\n";
}
?>