<?php
// Simple test for the API
session_start();

// Simulate being logged in as tutor
$_SESSION['user_id'] = 13;
$_SESSION['role'] = 'tutor';

echo "Testing API call...\n";
echo "User ID: " . $_SESSION['user_id'] . "\n";
echo "Role: " . $_SESSION['role'] . "\n";

// Test the API
$url = "http://localhost/TPLearn/api/get-assignment-submissions.php?material_id=6";
echo "Calling: " . $url . "\n";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_COOKIE, session_name() . '=' . session_id());
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: " . $httpCode . "\n";
echo "Response: " . $response . "\n";
?>