<?php
require_once 'includes/data-helpers.php';

echo "=== Testing Tutor Dropdown HTML Output ===\n";

$tutors = getTutors();

echo "HTML for tutor dropdown:\n";
echo '<select id="assignedTutor" name="assignedTutor">' . "\n";
echo '  <option value="">Select Tutor</option>' . "\n";

foreach ($tutors as $tutor) {
    echo '  <option value="' . htmlspecialchars($tutor['id']) . '">';
    echo htmlspecialchars($tutor['name']);
    if (!empty($tutor['specializations'])) {
        echo ' - ' . htmlspecialchars($tutor['specializations']);
    }
    echo '</option>' . "\n";
}

echo '</select>' . "\n";
?>