<?php
require_once 'includes/db.php';

// Reset admin password to 'admin123'
$newPassword = 'admin123';
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = 'tplearnph@gmail.com'");
$stmt->bind_param("s", $hashedPassword);

if ($stmt->execute()) {
    echo "Admin password has been reset to: " . $newPassword . "\n";
    echo "Please delete this file after use for security.\n";
} else {
    echo "Error updating password: " . $conn->error . "\n";
}

$stmt->close();
?>