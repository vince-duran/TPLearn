<?php
require_once 'includes/data-helpers.php';

echo "=== Testing Fixed getTutorAssignedPrograms Function ===\n\n";

// Test with Sarah Geronimo's user ID (13)
echo "Testing with Sarah Geronimo's user ID (13):\n";
$programs = getTutorAssignedPrograms(13);

echo "Programs found: " . count($programs) . "\n\n";

if (count($programs) > 0) {
    foreach ($programs as $program) {
        echo "Program Details:\n";
        echo "  ID: " . $program['id'] . "\n";
        echo "  Name: " . $program['name'] . "\n";
        echo "  Tutor Name: " . ($program['tutor_name'] ?? 'N/A') . "\n";
        echo "  Student Count: " . $program['student_count'] . "\n";
        echo "  Start Date: " . ($program['start_date'] ?? 'N/A') . "\n";
        echo "  End Date: " . ($program['end_date'] ?? 'N/A') . "\n";
        echo "  Time Range: " . ($program['time_range'] ?? 'N/A') . "\n";
        echo "  Days: " . ($program['days'] ?? 'N/A') . "\n";
        echo "  Fee: ₱" . number_format($program['fee'] ?? 0) . "\n";
        echo "  Status: " . ($program['status'] ?? 'N/A') . "\n";
        echo "---\n";
    }
} else {
    echo "No programs found for this tutor.\n";
}

echo "\nAlso testing with Jane Tutor (user ID 4):\n";
$programs_jane = getTutorAssignedPrograms(4);
echo "Programs found for Jane: " . count($programs_jane) . "\n";
foreach ($programs_jane as $program) {
    echo "  - " . $program['name'] . " (ID: " . $program['id'] . ")\n";
}
?>