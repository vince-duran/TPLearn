<?php
/**
 * Test the fixed attendance functionality
 */

session_start();

// Simulate tutor login
$_SESSION['user_id'] = 17;
$_SESSION['username'] = 'tutor3';
$_SESSION['role'] = 'tutor';

echo "=== ATTENDANCE FUNCTIONALITY TEST ===\n\n";

require_once 'includes/auth.php';
require_once 'includes/data-helpers.php';

// Test 1: Get program students with string user_ids
echo "1. Testing getProgramStudents with string user_ids...\n";
$students = getProgramStudents(37); // Advanced Mathematics
echo "   Found " . count($students) . " students:\n";

foreach ($students as $student) {
    echo "   - {$student['full_name']} (ID: {$student['user_id']}, String: {$student['user_id_string']})\n";
}
echo "\n";

// Test 2: Simulate saving attendance data
echo "2. Testing attendance save API simulation...\n";

$test_attendance_data = [];
foreach ($students as $student) {
    $test_attendance_data[] = [
        'student_user_id' => $student['user_id_string'], // Use string ID
        'status' => ($student['user_id'] % 2 == 0) ? 'present' : 'absent',
        'notes' => null
    ];
}

echo "   Test attendance data prepared:\n";
foreach ($test_attendance_data as $data) {
    echo "     - Student {$data['student_user_id']}: {$data['status']}\n";
}

// Test 3: Test the API by making a curl request
echo "\n3. Testing save-attendance API...\n";

$test_data = [
    'program_id' => 37,
    'session_date' => '2025-10-16', // Tomorrow
    'attendance_data' => $test_attendance_data
];

$json_data = json_encode($test_data);
echo "   Request data: " . $json_data . "\n";

// Test 4: Check existing attendance records
echo "\n4. Checking existing attendance records...\n";
require_once 'includes/db.php';

$sql = "SELECT a.*, s.session_date, s.enrollment_id FROM attendance a 
        JOIN sessions s ON a.session_id = s.id 
        WHERE s.tutor_user_id = 17 
        ORDER BY s.session_date DESC LIMIT 10";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "   Found " . $result->num_rows . " existing attendance records:\n";
    while ($row = $result->fetch_assoc()) {
        echo "     - Session {$row['session_id']}: {$row['student_user_id']} -> {$row['status']} on {$row['session_date']}\n";
    }
} else {
    echo "   No existing attendance records found.\n";
}

echo "\n=== TEST COMPLETED ===\n";
echo "✅ Ready to test in browser!\n";
echo "✅ Login as tutor3 and try saving attendance\n";
echo "✅ Check the console for any JavaScript errors\n";
?>