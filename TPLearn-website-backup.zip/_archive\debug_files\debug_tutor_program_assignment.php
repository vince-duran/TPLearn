<?php
require_once 'includes/db.php';

echo "=== Debugging Tutor Program Assignment Issue ===\n\n";

// 1. Check Sarah Geronimo's user and profile IDs
echo "1. Sarah Geronimo's IDs:\n";
$result = $conn->query("
  SELECT u.id as user_id, u.user_id as structured_user_id, u.email, 
         tp.id as tutor_profile_id, tp.first_name, tp.last_name
  FROM users u 
  LEFT JOIN tutor_profiles tp ON u.id = tp.user_id 
  WHERE u.email = 'tutor123@gmail.com'
");
if ($result && $row = $result->fetch_assoc()) {
    print_r($row);
} else {
    echo "No user found!\n";
}

echo "\n2. All programs in database:\n";
$result = $conn->query("SELECT id, name, tutor_id, created_at FROM programs ORDER BY created_at DESC");
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Program ID: {$row['id']}, Name: {$row['name']}, Tutor ID: {$row['tutor_id']}, Created: {$row['created_at']}\n";
    }
} else {
    echo "No programs found!\n";
}

echo "\n3. Testing getTutorAssignedPrograms function:\n";
require_once 'includes/data-helpers.php';

// Test with user_id (13)
echo "Testing with user_id 13:\n";
$programs = getTutorAssignedPrograms(13);
echo "Programs found: " . count($programs) . "\n";
foreach ($programs as $program) {
    echo "- {$program['name']} (ID: {$program['id']})\n";
}

echo "\n4. Testing query manually:\n";
$tutor_user_id = 13;
$result = $conn->query("
  SELECT p.*, 
         COUNT(DISTINCT e.student_user_id) as student_count,
         CONCAT(p.start_time, ' - ', p.end_time) as time_range,
         tp.id as tutor_profile_id
  FROM programs p 
  INNER JOIN tutor_profiles tp ON p.tutor_id = tp.id
  INNER JOIN users u ON tp.user_id = u.id
  LEFT JOIN enrollments e ON p.id = e.program_id AND e.status = 'active'
  WHERE u.id = $tutor_user_id 
  GROUP BY p.id
  ORDER BY p.start_date DESC
");

echo "Manual query results:\n";
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "- {$row['name']} (ID: {$row['id']}, Tutor Profile ID: {$row['tutor_profile_id']})\n";
    }
} else {
    echo "No programs found with manual query!\n";
}

echo "\n5. Check if tutor_id is user.id or tutor_profiles.id:\n";
$result = $conn->query("
  SELECT p.id, p.name, p.tutor_id,
         u.id as user_id, u.email,
         tp.id as tutor_profile_id, tp.first_name, tp.last_name
  FROM programs p
  LEFT JOIN users u ON p.tutor_id = u.id
  LEFT JOIN tutor_profiles tp ON p.tutor_id = tp.id
");

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "Program: {$row['name']}, tutor_id: {$row['tutor_id']}\n";
        echo "  - Matches user.id: " . ($row['user_id'] ? "YES (User: {$row['email']})" : "NO") . "\n";
        echo "  - Matches tutor_profiles.id: " . ($row['tutor_profile_id'] ? "YES (Tutor: {$row['first_name']} {$row['last_name']})" : "NO") . "\n";
        echo "---\n";
    }
}
?>