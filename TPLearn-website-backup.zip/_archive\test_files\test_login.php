<?php
session_start();

// Test login for tutor3
$username = 'tutor3';
$password = 'password';

require_once 'includes/db.php';

$sql = "SELECT id, username, password, email, role FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $username);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    echo "User found: " . print_r($user, true) . "\n";
    
    if (password_verify($password, $user['password'])) {
        echo "Password verified successfully!\n";
        
        // Set session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        
        echo "Session set: " . print_r($_SESSION, true) . "\n";
        
        // Now test the API
        echo "\n--- Testing API ---\n";
        require_once 'includes/data-helpers.php';
        
        $students = getProgramStudents(37);
        echo "Students found: " . count($students) . "\n";
        echo "Students data: " . print_r($students, true) . "\n";
        
    } else {
        echo "Password verification failed!\n";
        echo "Stored hash: " . $user['password'] . "\n";
        echo "Test password: " . $password . "\n";
    }
} else {
    echo "User not found!\n";
}
?>