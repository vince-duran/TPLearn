<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

echo "<h2>Debug Information</h2>";

// Check session
echo "<h3>Session Data:</h3>";
echo "<pre>";
print_r($_SESSION);
echo "</pre>";

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    echo "<h3>Current User Details:</h3>";
    
    // Get user details
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $user_result = $stmt->get_result();
    
    if ($user = $user_result->fetch_assoc()) {
        echo "<pre>";
        print_r($user);
        echo "</pre>";
        
        // Get tutor profile
        echo "<h3>Tutor Profile:</h3>";
        $stmt = $conn->prepare("SELECT * FROM tutor_profiles WHERE user_id = ?");
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $tutor_result = $stmt->get_result();
        
        if ($tutor = $tutor_result->fetch_assoc()) {
            echo "<pre>";
            print_r($tutor);
            echo "</pre>";
            
            // Check programs assigned to this tutor
            echo "<h3>Programs Query Check:</h3>";
            $stmt = $conn->prepare("
                SELECT p.*, tp.id as tutor_profile_id, tp.user_id as tutor_user_id
                FROM programs p 
                INNER JOIN tutor_profiles tp ON p.tutor_id = tp.id 
                WHERE tp.user_id = ?
            ");
            $stmt->bind_param('i', $user_id);
            $stmt->execute();
            $programs_result = $stmt->get_result();
            
            echo "Found " . $programs_result->num_rows . " programs<br>";
            
            while ($program = $programs_result->fetch_assoc()) {
                echo "<pre>";
                print_r($program);
                echo "</pre>";
            }
            
        } else {
            echo "No tutor profile found for user_id: $user_id";
            
            // Check all tutor profiles
            echo "<h3>All Tutor Profiles:</h3>";
            $result = $conn->query("SELECT * FROM tutor_profiles");
            while ($row = $result->fetch_assoc()) {
                echo "<pre>";
                print_r($row);
                echo "</pre>";
            }
        }
    } else {
        echo "No user found with ID: $user_id";
    }
} else {
    echo "No user logged in";
}

// Check all programs
echo "<h3>All Programs:</h3>";
$result = $conn->query("SELECT * FROM programs");
while ($row = $result->fetch_assoc()) {
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}
?>