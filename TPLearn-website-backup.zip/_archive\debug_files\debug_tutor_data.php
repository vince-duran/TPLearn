<?php
require_once 'includes/db.php';

// Check if tutor123@gmail.com exists
echo "=== Checking tutor123@gmail.com ===\n";
$result = $conn->query("SELECT * FROM users WHERE email = 'tutor123@gmail.com'");
if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "User found:\n";
    print_r($user);
    
    // Check tutor profile
    echo "\n=== Checking tutor profile ===\n";
    $profileResult = $conn->query("SELECT * FROM tutor_profiles WHERE user_id = " . $user['id']);
    if ($profileResult && $profileResult->num_rows > 0) {
        $profile = $profileResult->fetch_assoc();
        echo "Tutor profile found:\n";
        print_r($profile);
    } else {
        echo "No tutor profile found for this user.\n";
    }
} else {
    echo "User with email tutor123@gmail.com not found.\n";
}

// Show all tutors
echo "\n=== All tutors in database ===\n";
$result = $conn->query("
    SELECT u.id, u.email, u.username, u.role, u.status, 
           tp.first_name, tp.last_name, tp.specializations
    FROM users u
    LEFT JOIN tutor_profiles tp ON u.id = tp.user_id
    WHERE u.role = 'tutor'
    ORDER BY u.id
");

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: {$row['id']}, Email: {$row['email']}, Username: {$row['username']}, Status: {$row['status']}\n";
        echo "Name: {$row['first_name']} {$row['last_name']}, Specializations: {$row['specializations']}\n";
        echo "---\n";
    }
} else {
    echo "No tutors found in database.\n";
}
?>