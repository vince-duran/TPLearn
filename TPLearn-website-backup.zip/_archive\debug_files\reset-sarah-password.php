<?php
require_once 'includes/db.php';

// Reset Sarah's password to a known value
$new_password = 'sarah123';
$hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE user_id = 13");
$stmt->bind_param('s', $hashed_password);

if ($stmt->execute()) {
    echo "Sarah's password has been reset to: sarah123<br>";
    echo "Email: ";
    
    // Get Sarah's email
    $stmt = $conn->prepare("SELECT username, email FROM users WHERE user_id = 13");
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($user = $result->fetch_assoc()) {
        echo $user['email'] . "<br>";
        echo "Username: " . $user['username'] . "<br>";
    }
} else {
    echo "Error updating password";
}
?>