<?php
/**
 * Test the get-session-attendance API
 */

session_start();

// Set session for tutor3
$_SESSION['user_id'] = 17;
$_SESSION['role'] = 'tutor';
$_SESSION['username'] = 'tutor3';

echo "Testing get-session-attendance API...\n";

// Test loading the attendance we just saved
$program_id = 37;
$session_date = '2025-10-16';

echo "Loading attendance for program $program_id on $session_date...\n\n";

// Simulate the API call
require_once 'includes/auth.php';
require_once 'includes/db.php';

$tutor_user_id = $_SESSION['user_id'];

try {
    // Verify tutor has access to this program
    $stmt = $conn->prepare("
        SELECT p.id, p.name, p.start_time, p.end_time
        FROM programs p 
        WHERE p.id = ? AND p.tutor_id = ?
    ");
    $stmt->bind_param('ii', $program_id, $tutor_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Access denied to this program');
    }
    
    $program = $result->fetch_assoc();
    echo "✓ Program access verified: " . $program['name'] . "\n";
    
    // Get attendance data for this program and session date
    $stmt = $conn->prepare("
        SELECT 
            a.student_user_id as student_user_id_string,
            a.status,
            a.notes,
            a.recorded_at,
            sp.first_name,
            sp.last_name,
            u.email,
            u.id as student_numeric_id,
            u.user_id as student_user_id_string_alt,
            s.id as session_id
        FROM sessions s
        INNER JOIN enrollments e ON s.enrollment_id = e.id
        INNER JOIN attendance a ON s.id = a.session_id
        INNER JOIN users u ON a.student_user_id = u.user_id
        INNER JOIN student_profiles sp ON u.id = sp.user_id
        WHERE e.program_id = ? 
          AND DATE(s.session_date) = ?
          AND s.tutor_user_id = ?
    ");
    $stmt->bind_param('isi', $program_id, $session_date, $tutor_user_id);
    $stmt->execute();
    $attendance_result = $stmt->get_result();
    
    $attendance_data = [];
    while ($row = $attendance_result->fetch_assoc()) {
        $attendance_data[] = [
            'student_user_id' => $row['student_numeric_id'], // Use numeric ID for frontend
            'student_user_id_string' => $row['student_user_id_string'], // Keep string for reference
            'full_name' => $row['first_name'] . ' ' . $row['last_name'],
            'first_name' => $row['first_name'],
            'last_name' => $row['last_name'],
            'email' => $row['email'],
            'status' => $row['status'],
            'notes' => $row['notes'],
            'marked_at' => $row['recorded_at'],
            'session_id' => $row['session_id']
        ];
    }
    
    echo "✓ Found " . count($attendance_data) . " attendance records:\n";
    foreach ($attendance_data as $record) {
        echo "  - {$record['full_name']} ({$record['student_user_id_string']}): {$record['status']}\n";
    }
    
    // Get all enrolled students for comparison
    $stmt = $conn->prepare("
        SELECT 
            u.id as user_id,
            u.user_id as user_id_string,
            sp.first_name,
            sp.last_name,
            u.email
        FROM enrollments e
        INNER JOIN users u ON e.student_user_id = u.id
        INNER JOIN student_profiles sp ON u.id = sp.user_id
        WHERE e.program_id = ? AND e.status IN ('active', 'paused')
    ");
    $stmt->bind_param('i', $program_id);
    $stmt->execute();
    $students_result = $stmt->get_result();
    
    $all_students = [];
    while ($row = $students_result->fetch_assoc()) {
        $all_students[] = [
            'user_id' => $row['user_id'],
            'user_id_string' => $row['user_id_string'],
            'full_name' => $row['first_name'] . ' ' . $row['last_name'],
            'first_name' => $row['first_name'],
            'last_name' => $row['last_name'],
            'email' => $row['email']
        ];
    }
    
    echo "\n✓ Found " . count($all_students) . " enrolled students:\n";
    foreach ($all_students as $student) {
        echo "  - {$student['full_name']} ({$student['user_id_string']})\n";
    }
    
    $response = [
        'success' => true,
        'program' => $program,
        'session_date' => $session_date,
        'session_info' => [
            'date' => $session_date,
            'status' => 'completed'
        ],
        'attendance_data' => $attendance_data,
        'all_students' => $all_students
    ];
    
    echo "\n✅ API Response Structure:\n";
    echo json_encode($response, JSON_PRETTY_PRINT) . "\n";
    
} catch (Exception $e) {
    echo "\n❌ ERROR: " . $e->getMessage() . "\n";
}
?>