<?php
// Test script to debug the get-program-students.php API
echo "Testing get-program-students.php API\n";

// Also test direct inclusion
echo "\n--- Testing direct inclusion ---\n";
try {
    require_once 'includes/auth.php';
    require_once 'includes/data-helpers.php';
    
    // Simulate session for testing
    $_SESSION['user_id'] = 17;
    $_SESSION['role'] = 'tutor';
    $_SESSION['username'] = 'mike.johnson';
    
    echo "Session simulated for user ID: " . $_SESSION['user_id'] . "\n";
    
    $students = getProgramStudents(37);
    echo "Direct call result: " . print_r($students, true) . "\n";
    
    // Also test the getTutorAssignedPrograms function
    $programs = getTutorAssignedPrograms(17);
    echo "Tutor programs: " . print_r($programs, true) . "\n";
    
} catch (Exception $e) {
    echo "Error in direct call: " . $e->getMessage() . "\n";
}
?>