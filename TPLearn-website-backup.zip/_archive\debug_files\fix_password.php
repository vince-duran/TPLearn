<?php
require_once 'includes/db.php';

$password_hash = password_hash('password', PASSWORD_DEFAULT);
echo "Generated hash: $password_hash\n";

$sql = "UPDATE users SET password = ? WHERE id = 17";
$stmt = $conn->prepare($sql);
$stmt->bind_param('s', $password_hash);

if ($stmt->execute()) {
    echo "Password updated successfully!\n";
    
    // Verify update
    $verify_sql = "SELECT password FROM users WHERE id = 17";
    $verify_result = $conn->query($verify_sql);
    $row = $verify_result->fetch_assoc();
    echo "Stored hash: " . $row['password'] . "\n";
    
    // Test verification
    if (password_verify('password', $row['password'])) {
        echo "Password verification successful!\n";
    } else {
        echo "Password verification failed!\n";
    }
} else {
    echo "Error updating password: " . $stmt->error . "\n";
}
?>