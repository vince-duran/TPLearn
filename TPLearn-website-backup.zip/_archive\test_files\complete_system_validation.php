<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

echo "<h1>🚀 Complete Multi-Tutor System Validation</h1>";

// Test data: All tutors in the system
$tutors_test_data = [
    [
        'id' => 4,
        'user_id' => 'TPT2025-001',
        'username' => 'testtutor',
        'name' => 'Jane Tutor'
    ],
    [
        'id' => 13,
        'user_id' => 'TPT2025-577', 
        'username' => 'TUT2025-745',
        'name' => 'Sarah Geronimo'
    ],
    [
        'id' => 17,
        'user_id' => 'TPT2025-003',
        'username' => 'tutor3',
        'name' => 'Mike Johnson'
    ]
];

echo "<h2>1. Complete System Overview</h2>";

// Get current state from database
$sql = "SELECT u.id, u.user_id, u.username, u.role, 
               CONCAT(tp.first_name, ' ', tp.last_name) as full_name,
               tp.specializations,
               COUNT(p.id) as assigned_programs
        FROM users u 
        LEFT JOIN tutor_profiles tp ON u.id = tp.user_id 
        LEFT JOIN programs p ON u.id = p.tutor_id
        WHERE u.role = 'tutor' 
        GROUP BY u.id, u.user_id, u.username, u.role, tp.first_name, tp.last_name, tp.specializations
        ORDER BY u.id";

$result = $conn->query($sql);

echo "<table border='1' style='border-collapse: collapse; width: 100%; margin: 20px 0;'>";
echo "<tr style='background-color: #f3f4f6;'><th>User ID</th><th>String ID</th><th>Username</th><th>Full Name</th><th>Specializations</th><th>Programs</th><th>Profile Status</th></tr>";

$system_tutors = [];
while ($row = $result->fetch_assoc()) {
    $has_profile = !empty($row['full_name']) && $row['full_name'] !== ' ';
    $profile_status = $has_profile ? '✅ Complete' : '❌ Missing';
    
    echo "<tr>";
    echo "<td><strong>" . htmlspecialchars($row['id']) . "</strong></td>";
    echo "<td>" . htmlspecialchars($row['user_id']) . "</td>";
    echo "<td>" . htmlspecialchars($row['username']) . "</td>";
    echo "<td>" . htmlspecialchars($row['full_name'] ?: 'No Profile') . "</td>";
    echo "<td>" . htmlspecialchars($row['specializations'] ?: 'General') . "</td>";
    echo "<td><strong>" . htmlspecialchars($row['assigned_programs']) . "</strong></td>";
    echo "<td>$profile_status</td>";
    echo "</tr>";
    
    $system_tutors[] = $row;
}
echo "</table>";

echo "<h2>2. Individual Tutor Function Testing</h2>";

$all_tests_passed = true;

foreach ($system_tutors as $tutor) {
    echo "<div style='border: 2px solid #d1d5db; border-radius: 10px; padding: 20px; margin: 20px 0; background: #f9fafb;'>";
    echo "<h3>👨‍🏫 {$tutor['full_name']} (ID: {$tutor['id']})</h3>";
    
    // Test integer ID (session scenario)
    echo "<div style='background: white; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h4>🔢 Integer ID Test (Session Scenario)</h4>";
    
    $start_time = microtime(true);
    $full_name_int = getTutorFullName($tutor['id']);
    $programs_int = getTutorAssignedPrograms($tutor['id']);
    $end_time = microtime(true);
    $execution_time_int = round(($end_time - $start_time) * 1000, 2);
    
    echo "<ul>";
    echo "<li><strong>Function Call:</strong> getTutorFullName({$tutor['id']})</li>";
    echo "<li><strong>Result:</strong> " . htmlspecialchars($full_name_int) . "</li>";
    echo "<li><strong>Programs Found:</strong> " . count($programs_int) . " programs</li>";
    echo "<li><strong>Execution Time:</strong> {$execution_time_int}ms</li>";
    echo "</ul>";
    echo "</div>";
    
    // Test string ID (alternative scenario)
    echo "<div style='background: white; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h4>📝 String ID Test (Alternative Scenario)</h4>";
    
    $start_time = microtime(true);
    $full_name_str = getTutorFullName($tutor['user_id']);
    $programs_str = getTutorAssignedPrograms($tutor['user_id']);
    $end_time = microtime(true);
    $execution_time_str = round(($end_time - $start_time) * 1000, 2);
    
    echo "<ul>";
    echo "<li><strong>Function Call:</strong> getTutorFullName('{$tutor['user_id']}')</li>";
    echo "<li><strong>Result:</strong> " . htmlspecialchars($full_name_str) . "</li>";
    echo "<li><strong>Programs Found:</strong> " . count($programs_str) . " programs</li>";
    echo "<li><strong>Execution Time:</strong> {$execution_time_str}ms</li>";
    echo "</ul>";
    echo "</div>";
    
    // Validation
    $name_consistent = ($full_name_int === $full_name_str);
    $programs_consistent = (count($programs_int) === count($programs_str));
    $expected_programs = (int)$tutor['assigned_programs'];
    $program_count_correct = (count($programs_int) === $expected_programs);
    
    $test_passed = $name_consistent && $programs_consistent && $program_count_correct;
    $all_tests_passed = $all_tests_passed && $test_passed;
    
    echo "<div style='background: " . ($test_passed ? '#d1fae5' : '#fee2e2') . "; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h4 style='margin: 0 0 10px 0; color: " . ($test_passed ? '#065f46' : '#991b1b') . ";'>🧪 Test Results</h4>";
    echo "<ul style='margin: 0; color: " . ($test_passed ? '#065f46' : '#991b1b') . ";'>";
    echo "<li><strong>Name Consistency:</strong> " . ($name_consistent ? "✅ PASS" : "❌ FAIL") . "</li>";
    echo "<li><strong>Program Count Consistency:</strong> " . ($programs_consistent ? "✅ PASS" : "❌ FAIL") . "</li>";
    echo "<li><strong>Correct Program Count:</strong> " . ($program_count_correct ? "✅ PASS" : "❌ FAIL") . " (Expected: $expected_programs, Got: " . count($programs_int) . ")</li>";
    echo "<li><strong>Overall Status:</strong> " . ($test_passed ? "✅ ALL TESTS PASSED" : "❌ SOME TESTS FAILED") . "</li>";
    echo "</ul>";
    echo "</div>";
    
    // Show program details if any
    if (!empty($programs_int)) {
        echo "<div style='background: white; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
        echo "<h4>📚 Assigned Programs</h4>";
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr style='background-color: #f3f4f6;'><th>ID</th><th>Name</th><th>Category</th><th>Status</th><th>Students</th><th>Fee</th></tr>";
        foreach ($programs_int as $program) {
            echo "<tr>";
            echo "<td>" . htmlspecialchars($program['id']) . "</td>";
            echo "<td>" . htmlspecialchars($program['name']) . "</td>";
            echo "<td>" . htmlspecialchars($program['category']) . "</td>";
            echo "<td>" . htmlspecialchars($program['program_status']) . "</td>";
            echo "<td>" . htmlspecialchars($program['enrolled_students']) . "</td>";
            echo "<td>₱" . number_format($program['fee'], 2) . "</td>";
            echo "</tr>";
        }
        echo "</table>";
        echo "</div>";
    }
    
    echo "</div>";
}

echo "<h2>3. Admin Assignment System Test</h2>";

echo "<div style='background: white; padding: 20px; border-radius: 10px; border: 2px solid #e5e7eb; margin: 20px 0;'>";
echo "<h3>🎯 Admin Dropdown Verification</h3>";

$admin_tutors = getTutors();
echo "<p><strong>Available tutors for admin program assignment:</strong></p>";

echo "<div style='background: #f9fafb; padding: 15px; border-radius: 8px; margin: 15px 0;'>";
echo "<h4>Admin Dropdown Preview:</h4>";
echo "<select style='width: 100%; padding: 10px; font-size: 16px; border: 2px solid #d1d5db; border-radius: 6px;'>";
echo "<option value=''>Select Tutor</option>";
foreach ($admin_tutors as $tutor) {
    $specialization = (!empty($tutor['specialization']) && $tutor['specialization'] !== 'General') 
        ? ' - ' . $tutor['specialization'] 
        : '';
    echo "<option value='{$tutor['id']}'>{$tutor['name']}{$specialization}</option>";
}
echo "</select>";
echo "</div>";

echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background-color: #f3f4f6;'><th>Dropdown Value</th><th>Display Name</th><th>Specialization</th><th>Current Programs</th><th>Status</th></tr>";

$admin_system_working = true;
foreach ($admin_tutors as $tutor) {
    $status = "✅ Ready";
    if (empty($tutor['name']) || $tutor['name'] === $tutor['username']) {
        $status = "⚠️ No Profile";
        $admin_system_working = false;
    }
    
    echo "<tr>";
    echo "<td><strong>" . htmlspecialchars($tutor['id']) . "</strong></td>";
    echo "<td>" . htmlspecialchars($tutor['name']) . "</td>";
    echo "<td>" . htmlspecialchars($tutor['specialization'] ?? 'General') . "</td>";
    echo "<td>" . htmlspecialchars($tutor['program_count'] ?? 0) . "</td>";
    echo "<td>$status</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

echo "<h2>4. System Performance & Health Report</h2>";

$total_tutors = count($system_tutors);
$tutors_with_profiles = 0;
$tutors_with_programs = 0;
$total_programs = 0;

foreach ($system_tutors as $tutor) {
    if (!empty($tutor['full_name']) && $tutor['full_name'] !== ' ') {
        $tutors_with_profiles++;
    }
    if ($tutor['assigned_programs'] > 0) {
        $tutors_with_programs++;
        $total_programs += $tutor['assigned_programs'];
    }
}

$profile_completion = round(($tutors_with_profiles / $total_tutors) * 100);
$program_assignment = round(($tutors_with_programs / $total_tutors) * 100);

echo "<div style='display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px; margin: 20px 0;'>";

echo "<div style='background: linear-gradient(135deg, #10b981, #059669); color: white; padding: 20px; border-radius: 10px; text-align: center;'>";
echo "<h3 style='margin: 0 0 10px 0;'>👥 Total Tutors</h3>";
echo "<p style='font-size: 36px; font-weight: bold; margin: 0;'>$total_tutors</p>";
echo "</div>";

echo "<div style='background: linear-gradient(135deg, #3b82f6, #1d4ed8); color: white; padding: 20px; border-radius: 10px; text-align: center;'>";
echo "<h3 style='margin: 0 0 10px 0;'>📚 Total Programs</h3>";
echo "<p style='font-size: 36px; font-weight: bold; margin: 0;'>$total_programs</p>";
echo "</div>";

echo "<div style='background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white; padding: 20px; border-radius: 10px; text-align: center;'>";
echo "<h3 style='margin: 0 0 10px 0;'>📊 Profile Completion</h3>";
echo "<p style='font-size: 36px; font-weight: bold; margin: 0;'>{$profile_completion}%</p>";
echo "</div>";

echo "</div>";

// Overall system status
$system_health = ($all_tests_passed && $admin_system_working) ? 'EXCELLENT' : 'GOOD';
$health_color = ($system_health === 'EXCELLENT') ? '#10b981' : '#f59e0b';

echo "<div style='background: white; border: 4px solid $health_color; border-radius: 15px; padding: 30px; text-align: center; margin: 30px 0;'>";
echo "<h2 style='color: $health_color; margin: 0 0 20px 0;'>🏆 System Health: $system_health</h2>";

if ($all_tests_passed && $admin_system_working) {
    echo "<div style='color: #065f46;'>";
    echo "<p style='font-size: 18px; margin: 10px 0;'>✅ All tutor functions working correctly for all users</p>";
    echo "<p style='font-size: 18px; margin: 10px 0;'>✅ Admin assignment system fully operational</p>";
    echo "<p style='font-size: 18px; margin: 10px 0;'>✅ Both integer and string ID methods working seamlessly</p>";
    echo "<p style='font-size: 18px; margin: 10px 0;'>✅ System scales properly with multiple tutors</p>";
    echo "</div>";
} else {
    echo "<div style='color: #92400e;'>";
    echo "<p style='font-size: 18px; margin: 10px 0;'>⚠️ Some minor issues detected - check individual test results</p>";
    echo "<p style='font-size: 18px; margin: 10px 0;'>⚠️ System functional but may need profile completion</p>";
    echo "</div>";
}

echo "</div>";

echo "<h2>5. Integration Workflow Summary</h2>";
echo "<div style='background: #f0f9ff; padding: 20px; border-radius: 10px; border-left: 6px solid #0284c7;'>";
echo "<h3 style='color: #0284c7; margin: 0 0 15px 0;'>🔄 Complete End-to-End Process</h3>";
echo "<ol style='color: #0284c7; font-size: 16px; line-height: 1.6;'>";
echo "<li><strong>Admin Management:</strong> Create/edit programs → Select any tutor from dropdown → System uses correct user ID</li>";
echo "<li><strong>Database Storage:</strong> programs.tutor_id stores integer user ID → Maintains referential integrity</li>";
echo "<li><strong>Tutor Login:</strong> Session stores integer user ID → Consistent with database relationships</li>";
echo "<li><strong>Program Retrieval:</strong> Functions handle both ID types → Seamless experience for all scenarios</li>";
echo "<li><strong>Dashboard Display:</strong> All tutors see their assigned programs → Real-time synchronization</li>";
echo "</ol>";
echo "</div>";

?>

<style>
body { 
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
    line-height: 1.6;
    margin: 0;
    padding: 20px;
    background: #f8fafc;
}
table { 
    margin: 15px 0; 
    font-size: 14px;
}
th { 
    background-color: #f3f4f6;
    font-weight: 600;
    text-align: left;
}
td, th { 
    padding: 10px 12px; 
    border: 1px solid #e5e7eb;
}
h1 { 
    color: #111827; 
    text-align: center;
    margin-bottom: 30px;
}
h2 { 
    color: #111827; 
    border-bottom: 3px solid #e5e7eb;
    padding-bottom: 10px;
}
h3, h4 { 
    color: #374151; 
}
</style>