<?php
require_once 'includes/data-helpers.php';

echo "=== Testing getTutorDashboardData function ===\n";

// Test with tutor ID 13 (Sarah Geronimo)
$tutor_data = getTutorDashboardData(13);

echo "Tutor Dashboard Data:\n";
print_r($tutor_data);

echo "\nKey fields:\n";
echo "Name: " . ($tutor_data['name'] ?? 'NOT SET') . "\n";
echo "First Name: " . ($tutor_data['first_name'] ?? 'NOT SET') . "\n";
echo "Last Name: " . ($tutor_data['last_name'] ?? 'NOT SET') . "\n";
echo "Specialization: " . ($tutor_data['specialization'] ?? 'NOT SET') . "\n";
echo "Total Students: " . ($tutor_data['total_students'] ?? 'NOT SET') . "\n";
echo "Assigned Programs: " . ($tutor_data['assigned_programs'] ?? 'NOT SET') . "\n";
echo "Sessions Today: " . ($tutor_data['sessions_today'] ?? 'NOT SET') . "\n";
?>