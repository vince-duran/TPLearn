<?php
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

echo "<h2>Testing Tutor Functions with Integer ID</h2>";

// Test with integer ID (what's in session)
$sarah_integer_id = 13;
echo "<h3>Testing with integer ID: $sarah_integer_id</h3>";

echo "<h4>1. getTutorFullName($sarah_integer_id)</h4>";
$full_name = getTutorFullName($sarah_integer_id);
echo "<p>Result: " . htmlspecialchars($full_name) . "</p>";

echo "<h4>2. getTutorAssignedPrograms($sarah_integer_id)</h4>";
$programs = getTutorAssignedPrograms($sarah_integer_id);
echo "<p>Number of programs: " . count($programs) . "</p>";

if (!empty($programs)) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID</th><th>Name</th><th>Status</th><th>Students</th><th>Start Date</th></tr>";
    foreach ($programs as $program) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($program['id']) . "</td>";
        echo "<td>" . htmlspecialchars($program['name']) . "</td>";
        echo "<td>" . htmlspecialchars($program['program_status']) . "</td>";
        echo "<td>" . htmlspecialchars($program['enrolled_students']) . "</td>";
        echo "<td>" . htmlspecialchars($program['start_date'] ?? 'TBD') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>No programs found!</p>";
}

// Test with string ID for comparison
echo "<h3>Testing with string ID: TPT2025-577</h3>";
$sarah_string_id = 'TPT2025-577';

echo "<h4>1. getTutorFullName('$sarah_string_id')</h4>";
$full_name_string = getTutorFullName($sarah_string_id);
echo "<p>Result: " . htmlspecialchars($full_name_string) . "</p>";

echo "<h4>2. getTutorAssignedPrograms('$sarah_string_id')</h4>";
$programs_string = getTutorAssignedPrograms($sarah_string_id);
echo "<p>Number of programs: " . count($programs_string) . "</p>";

// Debug query
echo "<h3>Debug: Direct Database Query</h3>";
$sql = "SELECT p.id, p.name, p.tutor_id, u.username 
        FROM programs p 
        LEFT JOIN users u ON p.tutor_id = u.id 
        WHERE p.tutor_id = 13";
$result = $conn->query($sql);
echo "<p>Direct query for tutor_id=13: " . ($result ? $result->num_rows : 0) . " programs found</p>";

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Program ID</th><th>Name</th><th>Tutor ID</th><th>Username</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tutor_id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['username']) . "</td>";
        echo "</tr>";
    }
    echo "</table>";
}
?>