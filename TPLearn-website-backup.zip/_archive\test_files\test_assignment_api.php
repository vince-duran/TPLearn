<?php
// Test the assignment status API
session_start();

// Simulate student login
$_SESSION['user_id'] = 'TPS2025-001';
$_SESSION['role'] = 'student';

// Change to the API directory
chdir(__DIR__ . '/api');

// Test assignment ID 6 (one of the assignments for program 32)
$assignment_id = 6;

echo "Testing assignment status API for assignment ID: $assignment_id\n";
echo "Student: {$_SESSION['user_id']}\n\n";

// Simulate POST request with JSON input
$_SERVER['REQUEST_METHOD'] = 'POST';
$json_input = json_encode(['assignment_id' => $assignment_id]);

// Mock the php://input for JSON data
$old_input = 'php://input';
file_put_contents('php://temp', $json_input);

// Create a custom input stream
$GLOBALS['test_input'] = $json_input;

// Capture output
ob_start();

// Mock file_get_contents to return our test data
function mock_file_get_contents($filename) {
    if ($filename === 'php://input') {
        return $GLOBALS['test_input'];
    }
    return file_get_contents($filename);
}

// Replace file_get_contents temporarily
$backup = 'file_get_contents';
eval('function file_get_contents($filename) { return mock_file_get_contents($filename); }');

include 'get-assignment-status.php';
$output = ob_get_clean();

echo "API Response:\n";
echo $output;
?>