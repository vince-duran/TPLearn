<?php
include 'includes/db.php';

echo "=== ENROLLMENTS ===\n";
$result = mysqli_query($conn, "SELECT e.*, p.name FROM enrollments e JOIN programs p ON e.program_id = p.id LIMIT 5");
while($row = mysqli_fetch_assoc($result)) {
    echo "Student: {$row['student_user_id']}, Program: {$row['name']} (ID: {$row['program_id']})\n";
}

echo "\n=== ASSIGNMENTS ===\n";
$result = mysqli_query($conn, "SELECT id, program_id, title, due_date FROM program_materials WHERE material_type = 'assignment'");
while($row = mysqli_fetch_assoc($result)) {
    echo "ID: {$row['id']}, Program: {$row['program_id']}, Title: {$row['title']}, Due: {$row['due_date']}\n";
}

echo "\n=== CHECK SPECIFIC STUDENT ACCESS ===\n";
// Check if student TPS2025-001 can access program 32
$student_id = 'TPS2025-001';
$program_id = 32;

$result = mysqli_query($conn, "
    SELECT e.*, p.name 
    FROM enrollments e 
    JOIN programs p ON e.program_id = p.id 
    WHERE e.student_user_id = '$student_id' AND e.program_id = $program_id
");

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    echo "Student $student_id is enrolled in program {$row['name']} (ID: $program_id)\n";
    
    // Now check assignments for this program
    $result = mysqli_query($conn, "SELECT * FROM program_materials WHERE program_id = $program_id AND material_type = 'assignment'");
    echo "Assignments available:\n";
    while($row = mysqli_fetch_assoc($result)) {
        echo "  - {$row['title']} (ID: {$row['id']}) Due: {$row['due_date']}\n";
    }
} else {
    echo "Student $student_id is NOT enrolled in program $program_id\n";
}
?>