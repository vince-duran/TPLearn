<?php
/**
 * Direct test of save-attendance API
 */

session_start();

// Set session for tutor3
$_SESSION['user_id'] = 17;
$_SESSION['role'] = 'tutor';
$_SESSION['username'] = 'tutor3';

echo "Testing save-attendance API directly...\n";

// Test data
$test_data = [
    'program_id' => 37,
    'session_date' => '2025-10-16',
    'attendance_data' => [
        [
            'student_user_id' => 'TPS2025-579',
            'status' => 'present',
            'notes' => null
        ],
        [
            'student_user_id' => 'TPS2025-001',
            'status' => 'absent',
            'notes' => null
        ],
        [
            'student_user_id' => 'TPS2025-002',
            'status' => 'present',
            'notes' => null
        ]
    ]
];

// Include the API file directly to test
echo "Input data: " . json_encode($test_data, JSON_PRETTY_PRINT) . "\n\n";

// Simulate POST data
$_SERVER['REQUEST_METHOD'] = 'POST';
$_SERVER['CONTENT_TYPE'] = 'application/json';

// Create a temporary file to simulate php://input
$temp_input = json_encode($test_data);
file_put_contents('temp_input.txt', $temp_input);

// Mock file_get_contents('php://input')
function test_file_get_contents($filename) {
    if ($filename === 'php://input') {
        return file_get_contents('temp_input.txt');
    }
    return file_get_contents($filename);
}

// Override the function temporarily
if (!function_exists('original_file_get_contents')) {
    function original_file_get_contents($filename) {
        return file_get_contents($filename);
    }
}

echo "Starting API test...\n";

// Capture output
ob_start();

// Set up headers
header('Content-Type: application/json');

// Include the API
require_once 'includes/auth.php';
require_once 'includes/db.php';

// Validate required fields
$input = json_decode($temp_input, true);

if (!$input) {
    echo json_encode(['error' => 'Invalid JSON input']);
    exit;
}

// Validate required fields
if (!isset($input['program_id']) || !isset($input['session_date']) || !isset($input['attendance_data'])) {
    echo json_encode(['error' => 'Missing required fields: program_id, session_date, attendance_data']);
    exit;
}

$program_id = intval($input['program_id']);
$session_date = $input['session_date'];
$attendance_data = $input['attendance_data'];
$tutor_user_id = $_SESSION['user_id'];

echo "Processing attendance for program $program_id on $session_date...\n";

try {
    // Start transaction
    $conn->autocommit(false);
    
    // Verify tutor has access to this program
    $stmt = $conn->prepare("
        SELECT p.id 
        FROM programs p 
        WHERE p.id = ? AND p.tutor_id = ?
    ");
    $stmt->bind_param('ii', $program_id, $tutor_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        throw new Exception('Access denied to this program');
    }
    
    echo "✓ Tutor authorization verified\n";
    
    // Get enrollments for this program to create sessions
    $stmt = $conn->prepare("
        SELECT e.id as enrollment_id, e.student_user_id, u.user_id as student_user_id_string
        FROM enrollments e
        INNER JOIN users u ON e.student_user_id = u.id
        WHERE e.program_id = ? AND e.status IN ('active', 'paused')
    ");
    $stmt->bind_param('i', $program_id);
    $stmt->execute();
    $enrollments_result = $stmt->get_result();
    
    $enrollments = [];
    while ($row = $enrollments_result->fetch_assoc()) {
        // Index by string user_id for easier lookup
        $enrollments[$row['student_user_id_string']] = [
            'enrollment_id' => $row['enrollment_id'],
            'student_user_id_int' => $row['student_user_id']
        ];
    }
    
    echo "✓ Found " . count($enrollments) . " enrollments\n";
    
    // Save attendance data
    $saved_count = 0;
    foreach ($attendance_data as $attendance) {
        if (!isset($attendance['student_user_id']) || !isset($attendance['status'])) {
            continue;
        }
        
        $student_user_id_string = $attendance['student_user_id']; // This is now a string like "TPS2025-579"
        $status = $attendance['status'];
        $notes = isset($attendance['notes']) ? $attendance['notes'] : null;
        
        echo "  Processing student: $student_user_id_string -> $status\n";
        
        // Validate status
        if (!in_array($status, ['present', 'absent', 'late', 'excused'])) {
            echo "    ✗ Invalid status: $status\n";
            continue;
        }
        
        // Check if enrollment exists
        if (!isset($enrollments[$student_user_id_string])) {
            echo "    ✗ No enrollment found for: $student_user_id_string\n";
            continue;
        }
        
        $enrollment_info = $enrollments[$student_user_id_string];
        $enrollment_id = $enrollment_info['enrollment_id'];
        $student_user_id_int = $enrollment_info['student_user_id_int'];
        
        // Create or get session for this enrollment and date
        // First check if session already exists
        $stmt = $conn->prepare("
            SELECT id FROM sessions 
            WHERE enrollment_id = ? AND tutor_user_id = ? AND student_user_id = ? AND DATE(session_date) = ?
            LIMIT 1
        ");
        $stmt->bind_param('iiis', $enrollment_id, $tutor_user_id, $student_user_id_int, $session_date);
        $stmt->execute();
        $existing_session = $stmt->get_result();
        
        if ($existing_session->num_rows > 0) {
            // Session exists, get its ID
            $session = $existing_session->fetch_assoc();
            $session_id = $session['id'];
            echo "    ✓ Using existing session: $session_id\n";
        } else {
            // Create new session
            $session_datetime = $session_date . ' ' . date('H:i:s');
            $stmt = $conn->prepare("
                INSERT INTO sessions (enrollment_id, tutor_user_id, student_user_id, session_date, status, description)
                VALUES (?, ?, ?, ?, 'completed', 'Attendance session')
            ");
            $stmt->bind_param('iiis', $enrollment_id, $tutor_user_id, $student_user_id_int, $session_datetime);
            $stmt->execute();
            $session_id = $conn->insert_id;
            echo "    ✓ Created new session: $session_id\n";
        }
        
        // Insert or update attendance using the string user_id
        $stmt = $conn->prepare("
            INSERT INTO attendance (session_id, student_user_id, status, notes)
            VALUES (?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            status = VALUES(status),
            notes = VALUES(notes),
            recorded_at = CURRENT_TIMESTAMP
        ");
        $stmt->bind_param('isss', $session_id, $student_user_id_string, $status, $notes);
        $stmt->execute();
        echo "    ✓ Saved attendance record\n";
        $saved_count++;
    }
    
    // Commit transaction
    $conn->commit();
    $conn->autocommit(true);
    
    echo "\n✅ SUCCESS: Attendance saved for {$saved_count} students on {$session_date}\n";
    
} catch (Exception $e) {
    // Rollback transaction
    $conn->rollback();
    $conn->autocommit(true);
    
    echo "\n❌ ERROR: " . $e->getMessage() . "\n";
}

// Clean up
unlink('temp_input.txt');

$output = ob_get_clean();
echo $output;
?>