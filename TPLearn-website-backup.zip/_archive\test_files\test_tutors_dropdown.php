<?php
require_once 'includes/data-helpers.php';

echo "=== Testing getTutors() function ===\n";

$tutors = getTutors();

echo "Total tutors found: " . count($tutors) . "\n\n";

if (empty($tutors)) {
    echo "No tutors found in database.\n";
} else {
    foreach ($tutors as $index => $tutor) {
        echo "Tutor " . ($index + 1) . ":\n";
        echo "  ID: " . ($tutor['id'] ?? 'N/A') . "\n";
        echo "  Name: " . ($tutor['name'] ?? 'N/A') . "\n";
        echo "  Email: " . ($tutor['email'] ?? 'N/A') . "\n";
        echo "  Specializations: " . ($tutor['specializations'] ?? 'N/A') . "\n";
        echo "  Status: " . ($tutor['status'] ?? 'N/A') . "\n";
        echo "  Student Count: " . ($tutor['student_count'] ?? 'N/A') . "\n";
        echo "---\n";
    }
}
?>