<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

// Simulate admin login for testing
$_SESSION['role'] = 'admin';
$_SESSION['username'] = 'admin';

echo "<h2>Debug: Tutor Dropdown Data</h2>";

$tutors = getTutors();

echo "<h3>Tutors returned by getTutors() function:</h3>";
echo "<pre>" . json_encode($tutors, JSON_PRETTY_PRINT) . "</pre>";

echo "<h3>What should appear in dropdown:</h3>";
foreach ($tutors as $tutor) {
    $specialization = (!empty($tutor['specializations']) && $tutor['specializations'] !== 'General') 
        ? ' - ' . $tutor['specializations'] 
        : '';
    
    echo "<p>Option value=\"{$tutor['id']}\": {$tutor['name']}{$specialization}</p>";
}
?>