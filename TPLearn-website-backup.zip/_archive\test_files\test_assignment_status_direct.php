<?php
// Simple direct test of assignment status functionality

// Include dependencies
include 'includes/db.php';

// Test data
$student_id_string = 'TPS2025-001';
$assignment_id = 6;

// Get numeric student ID
$result = $conn->query("SELECT id FROM users WHERE user_id = '$student_id_string'");
if ($result && $row = $result->fetch_assoc()) {
    $student_id = $row['id'];
} else {
    echo "Student not found\n";
    exit();
}

echo "Testing assignment status functionality directly\n";
echo "Student: $student_id_string (numeric ID: $student_id)\n";
echo "Assignment ID: $assignment_id\n\n";

try {
    // Get assignment details
    $stmt = $conn->prepare("
        SELECT 
            pm.id as assignment_id,
            pm.title,
            pm.description,
            pm.due_date,
            pm.created_at
        FROM program_materials pm
        WHERE pm.id = ? AND pm.material_type = 'assignment'
    ");
    
    $stmt->bind_param('i', $assignment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $assignment = $result->fetch_assoc();
    
    if (!$assignment) {
        echo "Assignment not found\n";
        exit();
    }
    
    echo "Assignment found:\n";
    echo "- Title: {$assignment['title']}\n";
    echo "- Description: {$assignment['description']}\n";
    echo "- Due date: {$assignment['due_date']}\n";
    echo "- Created: {$assignment['created_at']}\n\n";
    
    // Get submission details
    $stmt = $conn->prepare("
        SELECT 
            asub.id as submission_id,
            asub.submitted_at,
            asub.is_late,
            asub.grade,
            asub.feedback,
            asub.status,
            asub.graded_at,
            fu.original_name as submitted_file,
            fu.file_size,
            u_grader.username as graded_by_username
        FROM assignment_submissions asub
        LEFT JOIN file_uploads fu ON asub.file_upload_id = fu.id
        LEFT JOIN users u_grader ON asub.graded_by = u_grader.user_id
        WHERE asub.assignment_id = ? AND asub.student_id = ?
    ");
    
    $stmt->bind_param('ii', $assignment_id, $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $submission = $result->fetch_assoc();
    
    if ($submission) {
        echo "Submission found:\n";
        echo "- Submitted: {$submission['submitted_at']}\n";
        echo "- Status: {$submission['status']}\n";
        echo "- Grade: {$submission['grade']}\n";
        echo "- Is late: " . ($submission['is_late'] ? 'Yes' : 'No') . "\n";
    } else {
        echo "No submission found for this student\n";
    }
    
    // Calculate permissions
    $now = new DateTime();
    $due_date = new DateTime($assignment['due_date']);
    $can_submit = !$submission && $now <= $due_date;
    $can_unsubmit = $submission && !$submission['grade'] && $now <= $due_date;
    $is_past_due = $now > $due_date;
    $allow_late_submission = true;
    
    echo "\nPermissions:\n";
    echo "- Is past due: " . ($is_past_due ? 'Yes' : 'No') . "\n";
    echo "- Can submit: " . ($can_submit ? 'Yes' : 'No') . "\n";
    echo "- Can submit late: " . (($is_past_due && $allow_late_submission && !$submission) ? 'Yes' : 'No') . "\n";
    echo "- Can unsubmit: " . ($can_unsubmit ? 'Yes' : 'No') . "\n";
    
    // Build full response
    $response = [
        'success' => true,
        'assignment' => [
            'id' => $assignment['assignment_id'],
            'title' => $assignment['title'],
            'description' => $assignment['description'],
            'due_date' => $assignment['due_date'],
            'allow_late_submission' => $allow_late_submission,
            'is_past_due' => $is_past_due,
            'can_submit' => $can_submit || ($is_past_due && $allow_late_submission && !$submission),
            'created_at' => $assignment['created_at']
        ],
        'submission' => null
    ];
    
    if ($submission) {
        $response['submission'] = [
            'id' => $submission['submission_id'],
            'submitted_at' => $submission['submitted_at'],
            'is_late' => (bool)$submission['is_late'],
            'grade' => $submission['grade'],
            'feedback' => $submission['feedback'],
            'status' => $submission['status'],
            'graded_at' => $submission['graded_at'],
            'graded_by' => $submission['graded_by_username'],
            'file_name' => $submission['submitted_file'],
            'file_size' => $submission['file_size'],
            'can_unsubmit' => $can_unsubmit
        ];
    }
    
    echo "\nJSON Response:\n";
    echo json_encode($response, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>