<?php
require_once 'includes/db.php';
require_once 'includes/data-helpers.php';

echo "<h2>Testing Tutor Assignment System</h2>";

// Test the getTutors function
echo "<h3>Available Tutors for Assignment</h3>";
$tutors = getTutors();

if (!empty($tutors)) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>ID (for assignment)</th><th>Name</th><th>Username</th><th>Legacy User ID</th><th>Profile ID</th></tr>";
    foreach ($tutors as $tutor) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($tutor['id']) . "</td>"; // This should be users.id
        echo "<td>" . htmlspecialchars($tutor['name']) . "</td>";
        echo "<td>" . htmlspecialchars($tutor['username']) . "</td>";
        echo "<td>" . htmlspecialchars($tutor['legacy_user_id']) . "</td>";
        echo "<td>" . htmlspecialchars($tutor['tutor_profile_id'] ?? 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No tutors found!</p>";
}

// Test current program assignments
echo "<h3>Current Program Assignments</h3>";
$sql = "SELECT p.id, p.name, p.tutor_id, u.username, tp.first_name, tp.last_name 
        FROM programs p 
        LEFT JOIN users u ON p.tutor_id = u.id
        LEFT JOIN tutor_profiles tp ON u.id = tp.user_id
        ORDER BY p.id";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
    echo "<tr><th>Program ID</th><th>Program Name</th><th>Tutor ID (stored)</th><th>Username</th><th>Tutor Name</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['tutor_id'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($row['username'] ?? 'N/A') . "</td>";
        echo "<td>" . htmlspecialchars(trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')) ?: 'N/A') . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No programs found.</p>";
}
?>