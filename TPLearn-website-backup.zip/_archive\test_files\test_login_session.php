<?php
session_start();
require_once 'includes/db.php';

echo "=== Testing Login Session Update ===\n";

// Simulate the login process for tutor123@gmail.com
$email = 'tutor123@gmail.com';
$sql = "SELECT id, username, email, password, role, status FROM users WHERE email = ? LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($user = $result->fetch_assoc()) {
    echo "User found: {$user['email']}, Role: {$user['role']}\n";
    
    // Get the actual name based on role
    $name = '';
    if ($user['role'] === 'tutor') {
        $nameSql = "SELECT CONCAT(first_name, ' ', last_name) as full_name FROM tutor_profiles WHERE user_id = ?";
        $nameStmt = $conn->prepare($nameSql);
        $nameStmt->bind_param("i", $user['id']);
        $nameStmt->execute();
        $nameResult = $nameStmt->get_result();
        if ($nameRow = $nameResult->fetch_assoc()) {
            $name = $nameRow['full_name'];
        }
        $nameStmt->close();
    }
    
    echo "Retrieved name: '$name'\n";
    echo "Final session name would be: '" . ($name ?: $user['username']) . "'\n";
    
} else {
    echo "User not found!\n";
}

echo "\nCurrent session data:\n";
echo "user_id: " . ($_SESSION['user_id'] ?? 'NOT SET') . "\n";
echo "name: " . ($_SESSION['name'] ?? 'NOT SET') . "\n";
echo "email: " . ($_SESSION['email'] ?? 'NOT SET') . "\n";
echo "role: " . ($_SESSION['role'] ?? 'NOT SET') . "\n";
?>